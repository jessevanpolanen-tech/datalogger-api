import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Thermometer, Droplets, Battery, MapPin } from "lucide-react";
import { motion } from "framer-motion";

const statusColors = {
  active: "bg-green-100 text-green-800 border-green-200",
  alarm: "bg-red-100 text-red-800 border-red-200",
  maintenance: "bg-yellow-100 text-yellow-800 border-yellow-200",
  inactive: "bg-slate-100 text-slate-800 border-slate-200"
};

export default function DeviceStatusGrid({ devices, isLoading }) {
  if (isLoading) {
    return (
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>Device Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-slate-100 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Thermometer className="w-5 h-5 text-cyan-600" />
          Active Dataloggers
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {devices.map((device, index) => (
            <motion.div
              key={device.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
            >
              <div className="p-4 bg-gradient-to-br from-white to-slate-50 rounded-xl border border-slate-200 hover:shadow-md transition-all duration-200">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-semibold text-slate-900">{device.device_name}</h4>
                    <div className="flex items-center gap-1 text-sm text-slate-500 mt-1">
                      <MapPin className="w-3 h-3" />
                      {device.location}
                    </div>
                  </div>
                  <Badge className={`${statusColors[device.status]} border`}>
                    {device.status}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2">
                    {device.device_type.includes('temperature') && (
                      <div className="flex items-center gap-1 text-sm">
                        <Thermometer className="w-4 h-4 text-red-500" />
                        <span className="font-medium text-slate-700">Temp</span>
                      </div>
                    )}
                    {device.device_type.includes('humidity') && (
                      <div className="flex items-center gap-1 text-sm">
                        <Droplets className="w-4 h-4 text-blue-500" />
                        <span className="font-medium text-slate-700">Humidity</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Battery className={`w-4 h-4 ${device.battery_level > 20 ? 'text-green-500' : 'text-red-500'}`} />
                    <span className="text-sm font-medium text-slate-600">{device.battery_level}%</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}