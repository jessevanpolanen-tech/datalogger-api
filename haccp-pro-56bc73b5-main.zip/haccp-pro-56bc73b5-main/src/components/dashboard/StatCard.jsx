import React from 'react';
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function StatCard({ title, value, subtitle, icon: Icon, bgColor, textColor, trend }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="relative overflow-hidden border-none shadow-lg hover:shadow-xl transition-all duration-300">
        <div className={`absolute top-0 right-0 w-32 h-32 ${bgColor} opacity-10 rounded-full transform translate-x-12 -translate-y-12`} />
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-medium text-slate-600 mb-1">{title}</p>
              <h3 className={`text-3xl font-bold ${textColor}`}>{value}</h3>
            </div>
            <div className={`p-3 ${bgColor} bg-opacity-20 rounded-xl`}>
              <Icon className={`w-6 h-6 ${textColor}`} />
            </div>
          </div>
          {subtitle && (
            <p className="text-sm text-slate-500">{subtitle}</p>
          )}
          {trend && (
            <div className="mt-3 flex items-center gap-1 text-sm">
              <span className={trend.includes('+') ? 'text-green-600' : 'text-red-600'}>
                {trend}
              </span>
              <span className="text-slate-500">vs last period</span>
            </div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}