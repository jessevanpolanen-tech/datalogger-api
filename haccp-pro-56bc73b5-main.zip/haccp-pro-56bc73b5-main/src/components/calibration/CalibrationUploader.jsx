import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, FileText, CheckCircle, X } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function CalibrationUploader({ datalogger, onSuccess }) {
  const [uploading, setUploading] = useState(false);
  const [file, setFile] = useState(null);
  const [formData, setFormData] = useState({
    calibration_date: new Date().toISOString().split('T')[0],
    next_calibration_due: '',
    performed_by: '',
    calibration_standard: '',
    temperature_offset: 0,
    status: 'passed',
    notes: ''
  });

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploading(true);

    try {
      let certificateUrl = null;
      
      // Upload certificate file if provided
      if (file) {
        const uploadResult = await base44.integrations.Core.UploadFile({ file });
        certificateUrl = uploadResult.file_url;
      }

      // Create calibration record
      await base44.entities.Calibration.create({
        datalogger_id: datalogger.id,
        ...formData,
        certificate_url: certificateUrl
      });

      // Update datalogger calibration dates
      await base44.entities.Datalogger.update(datalogger.id, {
        last_calibration_date: formData.calibration_date,
        next_calibration_due: formData.next_calibration_due,
        drift_offset: formData.temperature_offset
      });

      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("Error uploading calibration:", error);
      alert("Failed to upload calibration. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <Card className="border-2 border-blue-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="w-5 h-5 text-blue-600" />
          Upload Calibration Certificate
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="calibration_date">Calibration Date *</Label>
              <Input
                id="calibration_date"
                type="date"
                value={formData.calibration_date}
                onChange={(e) => setFormData({...formData, calibration_date: e.target.value})}
                required
              />
            </div>
            <div>
              <Label htmlFor="next_due">Next Due Date *</Label>
              <Input
                id="next_due"
                type="date"
                value={formData.next_calibration_due}
                onChange={(e) => setFormData({...formData, next_calibration_due: e.target.value})}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="performed_by">Performed By</Label>
            <Input
              id="performed_by"
              value={formData.performed_by}
              onChange={(e) => setFormData({...formData, performed_by: e.target.value})}
              placeholder="Technician name"
            />
          </div>

          <div>
            <Label htmlFor="standard">Calibration Standard</Label>
            <Input
              id="standard"
              value={formData.calibration_standard}
              onChange={(e) => setFormData({...formData, calibration_standard: e.target.value})}
              placeholder="Reference standard used"
            />
          </div>

          <div>
            <Label htmlFor="offset">Temperature Offset (°C)</Label>
            <Input
              id="offset"
              type="number"
              step="0.01"
              value={formData.temperature_offset}
              onChange={(e) => setFormData({...formData, temperature_offset: parseFloat(e.target.value)})}
            />
          </div>

          <div>
            <Label htmlFor="certificate">Upload Certificate (PDF)</Label>
            <div className="mt-2">
              <input
                id="certificate"
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileChange}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById('certificate').click()}
                className="w-full"
              >
                {file ? (
                  <>
                    <FileText className="w-4 h-4 mr-2" />
                    {file.name}
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                  </>
                )}
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              type="submit"
              disabled={uploading}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {uploading ? (
                "Uploading..."
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Save Calibration
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}