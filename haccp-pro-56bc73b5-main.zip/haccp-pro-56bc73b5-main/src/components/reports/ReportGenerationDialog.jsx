import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { format } from "date-fns";

const reportTypes = [
  { value: "daily_summary", label: "Daily Summary", description: "Overview of daily operations and compliance" },
  { value: "deviation_report", label: "Deviation Report", description: "Analysis of all parameter deviations" },
  { value: "audit_trail", label: "Audit Trail", description: "Complete record of system activities" },
  { value: "compliance_certificate", label: "Compliance Certificate", description: "Official compliance certification" },
  { value: "haccp_plan", label: "HACCP Plan", description: "Full HACCP documentation" }
];

export default function ReportGenerationDialog({ open, onClose, onGenerate, generating }) {
  const [formData, setFormData] = useState({
    report_type: "daily_summary",
    title: "",
    period_start: format(new Date(), "yyyy-MM-dd"),
    period_end: format(new Date(), "yyyy-MM-dd"),
    status: "draft",
    notes: ""
  });

  const selectedReportType = reportTypes.find(t => t.value === formData.report_type);

  const handleSubmit = (e) => {
    e.preventDefault();
    onGenerate(formData);
  };

  const handleClose = () => {
    if (!generating) {
      onClose();
      setFormData({
        report_type: "daily_summary",
        title: "",
        period_start: format(new Date(), "yyyy-MM-dd"),
        period_end: format(new Date(), "yyyy-MM-dd"),
        status: "draft",
        notes: ""
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Generate New Report</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="report_type">Report Type *</Label>
            <Select
              value={formData.report_type}
              onValueChange={(value) => setFormData({...formData, report_type: value})}
              disabled={generating}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {reportTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    <div>
                      <div className="font-medium">{type.label}</div>
                      <div className="text-xs text-slate-500">{type.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedReportType && (
              <p className="text-xs text-slate-500 mt-1">{selectedReportType.description}</p>
            )}
          </div>

          <div>
            <Label htmlFor="title">Report Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              required
              disabled={generating}
              placeholder="e.g., Q1 2024 Compliance Report"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="period_start">Start Date *</Label>
              <Input
                id="period_start"
                type="date"
                value={formData.period_start}
                onChange={(e) => setFormData({...formData, period_start: e.target.value})}
                required
                disabled={generating}
              />
            </div>
            <div>
              <Label htmlFor="period_end">End Date *</Label>
              <Input
                id="period_end"
                type="date"
                value={formData.period_end}
                onChange={(e) => setFormData({...formData, period_end: e.target.value})}
                required
                disabled={generating}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="status">Report Status</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => setFormData({...formData, status: value})}
              disabled={generating}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="finalized">Finalized</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="notes">Additional Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              disabled={generating}
              rows={3}
              placeholder="Any specific requirements or notes for this report..."
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleClose} disabled={generating}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-cyan-600 hover:bg-cyan-700"
              disabled={generating}
            >
              {generating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                'Generate Report'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}