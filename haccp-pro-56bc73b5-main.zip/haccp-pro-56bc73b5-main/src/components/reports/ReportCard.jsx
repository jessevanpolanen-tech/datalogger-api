import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Calendar, User, Eye, Download, Trash2 } from "lucide-react";
import { format } from "date-fns";

const reportTypeColors = {
  daily_summary: "bg-blue-100 text-blue-800",
  deviation_report: "bg-red-100 text-red-800",
  audit_trail: "bg-purple-100 text-purple-800",
  compliance_certificate: "bg-green-100 text-green-800",
  haccp_plan: "bg-orange-100 text-orange-800"
};

const statusColors = {
  draft: "bg-gray-100 text-gray-800 border-gray-200",
  finalized: "bg-blue-100 text-blue-800 border-blue-200",
  approved: "bg-green-100 text-green-800 border-green-200"
};

export default function ReportCard({ report, onView, onDelete }) {
  return (
    <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
      <CardHeader>
        <div className="flex items-start justify-between mb-3">
          <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge className={reportTypeColors[report.report_type]}>
              {report.report_type.replace(/_/g, ' ')}
            </Badge>
            <Badge variant="outline" className={`${statusColors[report.status]} border`}>
              {report.status}
            </Badge>
          </div>
        </div>
        <CardTitle className="text-lg">{report.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-slate-600 mb-4 line-clamp-2">
          {report.summary || 'Comprehensive report with detailed analysis and recommendations'}
        </p>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4" />
            <span>
              {format(new Date(report.period_start), "MMM d")} - {format(new Date(report.period_end), "MMM d, yyyy")}
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <User className="w-4 h-4" />
            <span>{report.generated_by || report.created_by}</span>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onView(report)}
          >
            <Eye className="w-4 h-4 mr-2" />
            View
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDelete(report.id)}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}