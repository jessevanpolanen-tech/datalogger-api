import Dashboard from './pages/Dashboard';
import Monitoring from './pages/Monitoring';
import ControlPoints from './pages/ControlPoints';
import Alerts from './pages/Alerts';
import Reports from './pages/Reports';
import Devices from './pages/Devices';
import Shipments from './pages/Shipments';
import Investigations from './pages/Investigations';
import AuditMode from './pages/AuditMode';
import ShipmentDetail from './pages/ShipmentDetail';
import Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "Monitoring": Monitoring,
    "ControlPoints": ControlPoints,
    "Alerts": Alerts,
    "Reports": Reports,
    "Devices": Devices,
    "Shipments": Shipments,
    "Investigations": Investigations,
    "AuditMode": AuditMode,
    "ShipmentDetail": ShipmentDetail,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: Layout,
};