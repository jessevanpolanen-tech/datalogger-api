import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LayoutDashboard, Activity, Shield, FileText, Bell, Settings, Package, Thermometer, Search, FileCheck, CheckCircle } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Badge } from "@/components/ui/badge";

const navigationItems = [
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { title: "Monitoring", url: createPageUrl("Monitoring"), icon: Activity },
  { title: "Control Points", url: createPageUrl("ControlPoints"), icon: Shield },
  { title: "Devices", url: createPageUrl("Devices"), icon: Thermometer },
  { title: "Shipments", url: createPageUrl("Shipments"), icon: Package },
  { title: "Investigations", url: createPageUrl("Investigations"), icon: Search },
  { title: "Reports", url: createPageUrl("Reports"), icon: FileText },
  { title: "Alerts", url: createPageUrl("Alerts"), icon: Bell },
  { title: "Audit Mode", url: createPageUrl("AuditMode"), icon: FileCheck, highlight: true },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --primary: 200 100% 45%;
          --primary-foreground: 0 0% 100%;
          --background: 220 20% 97%;
          --foreground: 220 15% 10%;
          --card: 0 0% 100%;
          --muted: 220 15% 95%;
          --accent: 195 100% 45%;
        }
      `}</style>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 via-blue-50 to-cyan-50">
        <Sidebar className="border-r border-slate-200 bg-white/80 backdrop-blur-sm">
          <SidebarHeader className="border-b border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 text-lg">HACCP Pro</h2>
                  <p className="text-xs text-slate-500">Pharma Compliance</p>
                </div>
              </div>
            </div>
            {/* Compliance Badges */}
            <div className="mt-4 pt-4 border-t border-slate-200">
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  EN12830:2018
                </Badge>
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  GDP
                </Badge>
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  21 CFR Part 11
                </Badge>
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  GMP Annex 15
                </Badge>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2">
                Main Menu
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-cyan-50 hover:text-cyan-700 transition-all duration-200 rounded-xl mb-1 ${
                          location.pathname === item.url ? 'bg-cyan-50 text-cyan-700 shadow-sm' : 'text-slate-600'
                        } ${item.highlight ? 'bg-gradient-to-r from-purple-50 to-pink-50 hover:from-purple-100 hover:to-pink-100' : ''}`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                          {item.highlight && (
                            <Badge className="ml-auto bg-purple-600 text-white">NEW</Badge>
                          )}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-6">
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2">
                System Status
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <div className="px-4 py-3 space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Active Devices</span>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      12 Online
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Active Alerts</span>
                    <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                      3 Critical
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Compliance</span>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      98.7%
                    </Badge>
                  </div>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-200 p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 bg-gradient-to-br from-slate-200 to-slate-300 rounded-full flex items-center justify-center">
                <span className="text-slate-700 font-semibold text-sm">QA</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-slate-900 text-sm truncate">Quality Assurance</p>
                <p className="text-xs text-slate-500 truncate">Pharma Operations</p>
              </div>
            </div>
            
            {/* Support Contact */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <p className="text-xs font-semibold text-slate-700 mb-2">Need Help?</p>
              <div className="text-xs text-slate-600 space-y-1">
                <p>📧 support@haccp-pro.com</p>
                <p>📞 +31 20 123 4567</p>
                <p className="text-green-600 font-medium">Response time: &lt;2 hours</p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          {/* System Status Trust Banner */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-b border-green-200 px-6 py-2">
            <div className="flex items-center justify-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-800 font-medium">All Systems Operational</span>
              </div>
              <span className="text-slate-400">|</span>
              <span className="text-slate-600">Last Data Sync: 2 seconds ago</span>
              <span className="text-slate-400">|</span>
              <div className="flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-slate-600">Audit Trail: Active</span>
              </div>
            </div>
          </div>

          <header className="bg-white/60 backdrop-blur-md border-b border-slate-200 px-6 py-4 md:hidden sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-slate-900">HACCP Pro</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>

          {/* Footer with Support Info */}
          <footer className="bg-white border-t border-slate-200 px-6 py-4">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
              <div className="flex items-center gap-6">
                <span className="text-slate-600">© 2024 HACCP Pro - Pharma Compliance Platform</span>
                <div className="flex gap-2">
                  <Badge variant="outline" className="text-xs">EN12830:2018</Badge>
                  <Badge variant="outline" className="text-xs">GDP</Badge>
                  <Badge variant="outline" className="text-xs">21 CFR Part 11</Badge>
                </div>
              </div>
              <div className="flex items-center gap-4 text-slate-600">
                <span className="font-medium">Need Help?</span>
                <a href="mailto:support@haccp-pro.com" className="hover:text-cyan-600 transition-colors">
                  Live Chat
                </a>
                <span>|</span>
                <a href="mailto:support@haccp-pro.com" className="hover:text-cyan-600 transition-colors">
                  support@haccp-pro.com
                </a>
                <span>|</span>
                <a href="tel:+31201234567" className="hover:text-cyan-600 transition-colors">
                  +31 20 123 4567
                </a>
                <span className="text-xs text-green-600">Response: &lt;2hrs</span>
              </div>
            </div>
          </footer>
        </main>
      </div>
    </SidebarProvider>
  );
}