
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, AlertTriangle, CheckCircle, Clock, User } from "lucide-react";
import { format } from "date-fns";

const priorityColors = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800"
};

const statusColors = {
  open: "bg-red-100 text-red-800",
  investigating: "bg-yellow-100 text-yellow-800",
  pending_approval: "bg-blue-100 text-blue-800",
  closed: "bg-green-100 text-green-800"
};

export default function Investigations() {
  const [activeTab, setActiveTab] = useState("open");

  const { data: investigations = [] } = useQuery({
    queryKey: ['investigations', activeTab],
    queryFn: () => {
      if (activeTab === "all") return base44.entities.Investigation.list("-created_date");
      return base44.entities.Investigation.filter({ status: activeTab }, "-created_date");
    },
    initialData: [],
  });

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">CAPA Investigations</h1>
          <p className="text-slate-600">Corrective and Preventive Action workflows</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="open">Open</TabsTrigger>
            <TabsTrigger value="investigating">Investigating</TabsTrigger>
            <TabsTrigger value="pending_approval">Pending Approval</TabsTrigger>
            <TabsTrigger value="closed">Closed</TabsTrigger>
            <TabsTrigger value="all">All</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="grid md:grid-cols-2 gap-6">
          {investigations.map((inv) => (
            <Card key={inv.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-cyan-600" />
                    <span className="text-sm font-mono text-slate-600">
                      {inv.investigation_number || `INV-${inv.id.slice(0, 8)}`}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Badge className={priorityColors[inv.priority]}>
                      {inv.priority}
                    </Badge>
                    <Badge variant="outline" className={`${statusColors[inv.status]} border`}>
                      {inv.status.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                </div>
                <CardTitle className="text-lg">{inv.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-700 mb-4 line-clamp-3">
                  {inv.description}
                </p>

                {inv.root_cause && (
                  <div className="p-3 bg-orange-50 rounded-lg mb-4">
                    <p className="text-xs font-medium text-orange-900 mb-1">Root Cause</p>
                    <p className="text-sm text-orange-800">{inv.root_cause}</p>
                    {inv.root_cause_category && (
                      <Badge className="mt-2 bg-orange-100 text-orange-800">
                        {inv.root_cause_category.replace(/_/g, ' ')}
                      </Badge>
                    )}
                  </div>
                )}

                {inv.corrective_action && (
                  <div className="p-3 bg-blue-50 rounded-lg mb-4">
                    <p className="text-xs font-medium text-blue-900 mb-1">Corrective Action</p>
                    <p className="text-sm text-blue-800">{inv.corrective_action}</p>
                  </div>
                )}

                <div className="space-y-2 text-sm">
                  {inv.assigned_to && (
                    <div className="flex items-center gap-2 text-slate-600">
                      <User className="w-4 h-4" />
                      <span>Assigned to: {inv.assigned_to}</span>
                    </div>
                  )}
                  {inv.target_closure_date && (
                    <div className="flex items-center gap-2 text-slate-600">
                      <Clock className="w-4 h-4" />
                      <span>Target: {format(new Date(inv.target_closure_date), "MMM d, yyyy")}</span>
                    </div>
                  )}
                </div>

                {inv.signatures && inv.signatures.length > 0 && (
                  <div className="mt-4 pt-4 border-t">
                    <p className="text-xs font-medium text-slate-700 mb-2">E-Signatures</p>
                    <div className="space-y-1">
                      {inv.signatures.map((sig, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs text-slate-600">
                          <CheckCircle className="w-3 h-3 text-green-600" />
                          <span>{sig.role}: {sig.signed_by}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Conditional Empty State */}
        {investigations.length === 0 ? (
          activeTab === "open" ? (
            // New "Zero Open Issues" empty state
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
              <CardContent className="flex flex-col items-center justify-center py-16">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-green-900 mb-2">
                  ✓ Zero Open Issues
                </h3>
                <p className="text-green-800 font-medium text-lg mb-2">
                  Your Compliance Record is Spotless
                </p>
                <p className="text-green-700 text-center max-w-md">
                  This is <strong>exactly</strong> what you want to show an auditor.
                  All incidents resolved and documented.
                </p>
              </CardContent>
            </Card>
          ) : (
            // Original generic empty state for other tabs
            <Card className="border-none shadow-lg">
              <CardContent className="flex flex-col items-center justify-center py-16">
                <AlertTriangle className="w-20 h-20 text-slate-300 mb-4" />
                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  No {activeTab !== 'all' ? activeTab.replace(/_/g, ' ') : ''} investigations
                </h3>
                <p className="text-slate-600">
                  No investigations found in this category.
                </p>
              </CardContent>
            </Card>
          )
        ) : null}
      </div>
    </div>
  );
}
