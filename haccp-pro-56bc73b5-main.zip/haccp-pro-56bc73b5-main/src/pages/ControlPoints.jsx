import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Shield, Edit, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const statusColors = {
  compliant: "bg-green-100 text-green-800 border-green-200",
  warning: "bg-yellow-100 text-yellow-800 border-yellow-200",
  critical: "bg-red-100 text-red-800 border-red-200"
};

const categoryColors = {
  storage: "bg-blue-100 text-blue-800",
  production: "bg-purple-100 text-purple-800",
  packaging: "bg-pink-100 text-pink-800",
  transport: "bg-orange-100 text-orange-800",
  laboratory: "bg-cyan-100 text-cyan-800"
};

export default function ControlPoints() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingCCP, setEditingCCP] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    category: "storage",
    parameter_type: "temperature",
    min_acceptable: "",
    max_acceptable: "",
    target_value: "",
    unit: "°C",
    monitoring_frequency: "",
    corrective_action: "",
    status: "compliant"
  });

  const queryClient = useQueryClient();

  const { data: controlPoints = [], isLoading } = useQuery({
    queryKey: ['controlPoints'],
    queryFn: () => base44.entities.ControlPoint.list("-created_date"),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ControlPoint.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['controlPoints'] });
      setShowDialog(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ControlPoint.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['controlPoints'] });
      setShowDialog(false);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ControlPoint.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['controlPoints'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingCCP) {
      updateMutation.mutate({ id: editingCCP.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (ccp) => {
    setEditingCCP(ccp);
    setFormData(ccp);
    setShowDialog(true);
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      category: "storage",
      parameter_type: "temperature",
      min_acceptable: "",
      max_acceptable: "",
      target_value: "",
      unit: "°C",
      monitoring_frequency: "",
      corrective_action: "",
      status: "compliant"
    });
    setEditingCCP(null);
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Critical Control Points</h1>
            <p className="text-slate-600">Manage HACCP control parameters</p>
          </div>
          <Button 
            onClick={() => setShowDialog(true)}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Control Point
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {controlPoints.map((ccp) => (
            <Card key={ccp.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <CardTitle className="text-lg">{ccp.name}</CardTitle>
                  <Badge className={`${statusColors[ccp.status]} border`}>
                    {ccp.status}
                  </Badge>
                </div>
                <Badge className={categoryColors[ccp.category]}>
                  {ccp.category}
                </Badge>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">{ccp.description}</p>
                
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Parameter:</span>
                    <span className="font-medium">{ccp.parameter_type}</span>
                  </div>
                  {ccp.min_acceptable && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Min:</span>
                      <span className="font-medium">{ccp.min_acceptable} {ccp.unit}</span>
                    </div>
                  )}
                  {ccp.max_acceptable && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Max:</span>
                      <span className="font-medium">{ccp.max_acceptable} {ccp.unit}</span>
                    </div>
                  )}
                  {ccp.target_value && (
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Target:</span>
                      <span className="font-medium text-cyan-600">{ccp.target_value} {ccp.unit}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(ccp)}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteMutation.mutate(ccp.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Dialog open={showDialog} onOpenChange={(open) => {
          setShowDialog(open);
          if (!open) resetForm();
        }}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingCCP ? 'Edit Control Point' : 'Add Control Point'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({...formData, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="storage">Storage</SelectItem>
                      <SelectItem value="production">Production</SelectItem>
                      <SelectItem value="packaging">Packaging</SelectItem>
                      <SelectItem value="transport">Transport</SelectItem>
                      <SelectItem value="laboratory">Laboratory</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="parameter_type">Parameter Type *</Label>
                  <Select
                    value={formData.parameter_type}
                    onValueChange={(value) => setFormData({...formData, parameter_type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="temperature">Temperature</SelectItem>
                      <SelectItem value="humidity">Humidity</SelectItem>
                      <SelectItem value="pressure">Pressure</SelectItem>
                      <SelectItem value="time">Time</SelectItem>
                      <SelectItem value="ph">pH</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="min_acceptable">Min Acceptable</Label>
                  <Input
                    id="min_acceptable"
                    type="number"
                    step="0.1"
                    value={formData.min_acceptable}
                    onChange={(e) => setFormData({...formData, min_acceptable: parseFloat(e.target.value)})}
                  />
                </div>
                <div>
                  <Label htmlFor="max_acceptable">Max Acceptable</Label>
                  <Input
                    id="max_acceptable"
                    type="number"
                    step="0.1"
                    value={formData.max_acceptable}
                    onChange={(e) => setFormData({...formData, max_acceptable: parseFloat(e.target.value)})}
                  />
                </div>
                <div>
                  <Label htmlFor="target_value">Target Value</Label>
                  <Input
                    id="target_value"
                    type="number"
                    step="0.1"
                    value={formData.target_value}
                    onChange={(e) => setFormData({...formData, target_value: parseFloat(e.target.value)})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="unit">Unit</Label>
                  <Input
                    id="unit"
                    value={formData.unit}
                    onChange={(e) => setFormData({...formData, unit: e.target.value})}
                    placeholder="°C, %, kPa, etc."
                  />
                </div>
                <div>
                  <Label htmlFor="monitoring_frequency">Monitoring Frequency</Label>
                  <Input
                    id="monitoring_frequency"
                    value={formData.monitoring_frequency}
                    onChange={(e) => setFormData({...formData, monitoring_frequency: e.target.value})}
                    placeholder="e.g., Every 15 minutes"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="corrective_action">Corrective Action</Label>
                <Textarea
                  id="corrective_action"
                  value={formData.corrective_action}
                  onChange={(e) => setFormData({...formData, corrective_action: e.target.value})}
                  rows={2}
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-cyan-600 hover:bg-cyan-700">
                  {editingCCP ? 'Update' : 'Create'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}