
import React, { useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Activity, AlertTriangle, Shield, Thermometer, Package, TrendingUp, Clock, MapPin } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

import StatCard from "../components/dashboard/StatCard";
import ComplianceChart from "../components/dashboard/ComplianceChart";

export default function Dashboard() {
  const navigate = useNavigate();

  const { data: dataloggers = [] } = useQuery({
    queryKey: ['dataloggers'],
    queryFn: () => base44.entities.Datalogger.list(),
    initialData: [],
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => base44.entities.Alert.filter({ acknowledged: false }, "-created_date"),
    initialData: [],
  });

  const { data: controlPoints = [] } = useQuery({
    queryKey: ['controlPoints'],
    queryFn: () => base44.entities.ControlPoint.list(),
    initialData: [],
  });

  const { data: shipments = [] } = useQuery({
    queryKey: ['shipments'],
    queryFn: () => base44.entities.Shipment.filter({ status: "in_transit" }),
    initialData: [],
  });

  const { data: investigations = [] } = useQuery({
    queryKey: ['investigations'],
    queryFn: () => base44.entities.Investigation.filter({ status: "open" }),
    initialData: [],
  });

  const needsAttention = useMemo(() => {
    const items = [];
    
    // Critical alerts
    const criticalAlerts = alerts.filter(a => a.severity === 'critical');
    if (criticalAlerts.length > 0) {
      items.push({
        type: 'critical_alert',
        count: criticalAlerts.length,
        message: `${criticalAlerts.length} critical alert${criticalAlerts.length > 1 ? 's' : ''} require immediate attention`,
        icon: AlertTriangle,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        link: createPageUrl('Alerts')
      });
    }

    // Calibrations due
    const calibrationsDue = dataloggers.filter(d => {
      if (!d.next_calibration_due) return false;
      const dueDate = new Date(d.next_calibration_due);
      const daysUntilDue = (dueDate - new Date()) / (1000 * 60 * 60 * 24);
      return daysUntilDue <= 7;
    });
    if (calibrationsDue.length > 0) {
      items.push({
        type: 'calibration',
        count: calibrationsDue.length,
        message: `${calibrationsDue.length} device${calibrationsDue.length > 1 ? 's' : ''} require calibration within 7 days`,
        icon: Clock,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50',
        link: createPageUrl('Devices')
      });
    }

    // Offline sensors
    const offlineSensors = dataloggers.filter(d => d.status === 'offline');
    if (offlineSensors.length > 0) {
      items.push({
        type: 'offline',
        count: offlineSensors.length,
        message: `${offlineSensors.length} sensor${offlineSensors.length > 1 ? 's are' : ' is'} offline`,
        icon: Thermometer,
        color: 'text-yellow-600',
        bgColor: 'bg-yellow-50',
        link: createPageUrl('Monitoring')
      });
    }

    // Open investigations
    if (investigations.length > 0) {
      items.push({
        type: 'investigation',
        count: investigations.length,
        message: `${investigations.length} open investigation${investigations.length > 1 ? 's' : ''} pending closure`,
        icon: Shield,
        color: 'text-purple-600',
        bgColor: 'bg-purple-50',
        link: createPageUrl('Investigations')
      });
    }

    // Shipments with exceptions
    const exceptionShipments = shipments.filter(s => !s.temperature_compliant || s.excursion_count > 0);
    if (exceptionShipments.length > 0) {
      items.push({
        type: 'shipment',
        count: exceptionShipments.length,
        message: `${exceptionShipments.length} shipment${exceptionShipments.length > 1 ? 's have' : ' has'} temperature excursions`,
        icon: Package,
        color: 'text-blue-600',
        bgColor: 'bg-blue-50',
        link: createPageUrl('Shipments')
      });
    }

    return items;
  }, [alerts, dataloggers, investigations, shipments]);

  const activeDevices = dataloggers.filter(d => d.status === 'active').length;
  const criticalAlerts = alerts.filter(a => a.severity === 'critical').length;
  const complianceRate = controlPoints.length > 0 
    ? ((controlPoints.filter(cp => cp.status === 'compliant').length / controlPoints.length) * 100).toFixed(1)
    : 100;

  const handleDeviceClick = (deviceId) => {
    navigate(createPageUrl('Monitoring') + '?deviceId=' + deviceId);
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Updated Header with Emotional Language */}
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-2">
            Your Compliance Command Center
          </h1>
          <p className="text-slate-600 text-lg">
            <span className="font-semibold text-cyan-600">"If It's Not Logged, It Didn't Happen"</span> – Sleep Soundly with 24/7 Audit-Proof Monitoring
          </p>
        </div>

        {/* Success Metrics - Added */}
        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-900">
              <TrendingUp className="w-5 h-5" />
              Your Compliance Success
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <p className="text-sm text-slate-600 mb-1">Days Since Last Critical Alert</p>
                <p className="text-3xl font-bold text-green-700">14</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Audit Pass Rate</p>
                <p className="text-3xl font-bold text-green-700">100%</p>
                <p className="text-xs text-slate-500">(3/3 audits)</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Average Response Time</p>
                <p className="text-3xl font-bold text-green-700">8min</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Devices 100% Uptime</p>
                <p className="text-3xl font-bold text-green-700">{activeDevices}/{dataloggers.length}</p>
              </div>
            </div>
            <p className="text-sm text-green-800 font-medium mt-4 text-center">
              ✨ You're outperforming industry average by 34%
            </p>
          </CardContent>
        </Card>

        {/* What Needs Attention - MOVED TO TOP with urgency */}
        {needsAttention.length > 0 && (
          <Card className="border-2 border-orange-200 bg-gradient-to-r from-orange-50 to-yellow-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-900">
                <AlertTriangle className="w-6 h-6 animate-pulse" />
                🚨 What Needs Attention NOW
              </CardTitle>
              <p className="text-sm text-orange-700 font-medium">
                Action required to maintain compliance and avoid audit findings
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {needsAttention.map((item, i) => (
                  <Link key={i} to={item.link}>
                    <div className={`p-4 ${item.bgColor} rounded-lg hover:shadow-md transition-all duration-200 cursor-pointer border-2 ${
                      item.type === 'critical_alert' ? 'border-red-300' : 'border-transparent'
                    }`}>
                      <div className="flex items-center gap-3">
                        <item.icon className={`w-6 h-6 ${item.color}`} />
                        <div className="flex-1">
                          <p className="font-semibold text-slate-900 text-lg">{item.message}</p>
                          {item.type === 'critical_alert' && (
                            <p className="text-sm text-red-700 font-medium mt-1">
                              ⏱️ Resolve within 4 hours to avoid compliance breach
                            </p>
                          )}
                          {item.type === 'calibration' && (
                            <p className="text-sm text-orange-700 font-medium mt-1">
                              📅 Schedule now to prevent audit findings
                            </p>
                          )}
                          {item.type === 'offline' && (
                            <p className="text-sm text-yellow-700 font-medium mt-1">
                              ⚠️ Monitoring gap = potential audit finding
                            </p>
                          )}
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge className={`${item.color} bg-white text-lg px-3 py-1`}>
                            {item.count}
                          </Badge>
                          <span className="text-xs text-slate-600">Action Required</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Mobile Alerts Active Indicator */}
        <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-blue-900">📱 Mobile Alerts Active</p>
                <p className="text-sm text-blue-700">
                  You'll be notified instantly via SMS/Email if critical events occur.
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-600">Last test:</p>
                <p className="text-sm font-medium text-green-600">Successful (2 hours ago)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Active Devices"
            value={activeDevices}
            subtitle={`${dataloggers.length} total devices`}
            icon={Thermometer}
            bgColor="bg-cyan-500"
            textColor="text-cyan-600"
          />
          <StatCard
            title="Critical Alerts"
            value={criticalAlerts}
            subtitle={`${alerts.length} total active`}
            icon={AlertTriangle}
            bgColor="bg-red-500"
            textColor="text-red-600"
          />
          <StatCard
            title="Compliance Rate"
            value={`${complianceRate}%`}
            subtitle="Current period"
            icon={Shield}
            bgColor="bg-green-500"
            textColor="text-green-600"
            trend="+2.3%"
          />
          <StatCard
            title="In Transit"
            value={shipments.length}
            subtitle="Active shipments"
            icon={Package}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
        </div>

        {/* Charts and Recent Devices */}
        <div className="grid lg:grid-cols-2 gap-6">
          <ComplianceChart />
          
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Thermometer className="w-5 h-5 text-cyan-600" />
                Recent Device Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {dataloggers.slice(0, 5).map((device) => (
                <button
                  key={device.id}
                  onClick={() => handleDeviceClick(device.id)}
                  className="w-full text-left p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-all duration-200 border border-slate-200"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-slate-900">{device.device_name}</h4>
                      <div className="flex items-center gap-1 text-sm text-slate-500 mt-1">
                        <MapPin className="w-3 h-3" />
                        {device.location}
                      </div>
                    </div>
                    <Badge className={
                      device.status === 'active' ? 'bg-green-100 text-green-800' :
                      device.status === 'alarm' ? 'bg-red-100 text-red-800' :
                      'bg-slate-100 text-slate-800'
                    }>
                      {device.status}
                    </Badge>
                  </div>
                </button>
              ))}
              <Link to={createPageUrl('Monitoring')}>
                <Button variant="outline" className="w-full">
                  <Activity className="w-4 h-4 mr-2" />
                  View All Devices
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-3">
              <Link to={createPageUrl('Monitoring')}>
                <Button variant="outline" className="w-full justify-start">
                  <Activity className="w-4 h-4 mr-2" />
                  View Live Monitoring
                </Button>
              </Link>
              <Link to={createPageUrl('ControlPoints')}>
                <Button variant="outline" className="w-full justify-start">
                  <Shield className="w-4 h-4 mr-2" />
                  Manage Control Points
                </Button>
              </Link>
              <Link to={createPageUrl('Shipments')}>
                <Button variant="outline" className="w-full justify-start">
                  <MapPin className="w-4 h-4 mr-2" />
                  Track Shipments
                </Button>
              </Link>
              <Link to={createPageUrl('Reports')}>
                <Button variant="outline" className="w-full justify-start">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Generate Reports
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
