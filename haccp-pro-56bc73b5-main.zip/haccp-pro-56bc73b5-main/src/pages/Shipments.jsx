
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, MapPin, Thermometer, TrendingUp, AlertTriangle, Plus, Clock } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const statusColors = {
  preparing: "bg-blue-100 text-blue-800",
  in_transit: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  returned: "bg-gray-100 text-gray-800",
  exception: "bg-red-100 text-red-800"
};

export default function Shipments() {
  const navigate = useNavigate();

  const { data: shipments = [] } = useQuery({
    queryKey: ['shipments'],
    queryFn: () => base44.entities.Shipment.list("-created_date"),
    initialData: [],
  });

  const { data: sites = [] } = useQuery({
    queryKey: ['sites'],
    queryFn: () => base44.entities.Site.list(),
    initialData: [],
  });

  const { data: dataloggers = [] } = useQuery({
    queryKey: ['dataloggers'],
    queryFn: () => base44.entities.Datalogger.list(),
    initialData: [],
  });

  const getSiteName = (siteId) => {
    const site = sites.find(s => s.id === siteId);
    return site?.name || 'Unknown';
  };

  const handleShipmentClick = (shipmentId) => {
    navigate(createPageUrl('ShipmentDetail') + '?shipmentId=' + shipmentId);
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Shipment Tracking</h1>
            <p className="text-slate-600">Monitor temperature-controlled shipments in real-time</p>
          </div>
          <Button className="bg-cyan-600 hover:bg-cyan-700">
            <Plus className="w-4 h-4 mr-2" />
            New Shipment
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Package className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">In Transit</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {shipments.filter(s => s.status === 'in_transit').length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <Thermometer className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Compliant</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {shipments.filter(s => s.temperature_compliant).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Excursions</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {shipments.reduce((sum, s) => sum + (s.excursion_count || 0), 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Clock className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Avg MKT</p>
                  <p className="text-2xl font-bold text-slate-900">
                    {shipments.length > 0 
                      ? (shipments.reduce((sum, s) => sum + (s.mkt_value || 0), 0) / shipments.length).toFixed(1)
                      : '0'}°C
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Shipments List */}
        <div className="space-y-4">
          {shipments.map((shipment) => {
            const shipmentLoggers = dataloggers.filter(d => 
              shipment.datalogger_device_ids?.includes(d.device_id)
            );

            return (
              <Card 
                key={shipment.id} 
                className="border-none shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => handleShipmentClick(shipment.id)}
              >
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center">
                        <Package className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{shipment.shipment_number}</CardTitle>
                        <p className="text-sm text-slate-600">{shipment.product_description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={statusColors[shipment.status]}>
                        {shipment.status.replace(/_/g, ' ')}
                      </Badge>
                      {!shipment.temperature_compliant && (
                        <Badge className="bg-red-100 text-red-800 border-red-200 border">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          Excursion
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-4 gap-6">
                    {/* Route */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <MapPin className="w-4 h-4 text-slate-600" />
                        <span className="text-sm font-medium text-slate-700">Route</span>
                      </div>
                      <p className="text-sm text-slate-900 font-medium">
                        {getSiteName(shipment.origin_site_id)}
                      </p>
                      <p className="text-xs text-slate-500">↓</p>
                      <p className="text-sm text-slate-900 font-medium">
                        {getSiteName(shipment.destination_site_id)}
                      </p>
                    </div>

                    {/* Timeline */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-4 h-4 text-slate-600" />
                        <span className="text-sm font-medium text-slate-700">Timeline</span>
                      </div>
                      {shipment.departure_time && (
                        <p className="text-xs text-slate-600">
                          Departed: {format(new Date(shipment.departure_time), "MMM d, HH:mm")}
                        </p>
                      )}
                      {shipment.expected_arrival && (
                        <p className="text-xs text-slate-600">
                          Expected: {format(new Date(shipment.expected_arrival), "MMM d, HH:mm")}
                        </p>
                      )}
                      {shipment.actual_arrival && (
                        <p className="text-xs text-green-600 font-medium">
                          Delivered: {format(new Date(shipment.actual_arrival), "MMM d, HH:mm")}
                        </p>
                      )}
                    </div>

                    {/* Temperature Status */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Thermometer className="w-4 h-4 text-slate-600" />
                        <span className="text-sm font-medium text-slate-700">Temperature</span>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm">
                          <span className="text-slate-600">MKT: </span>
                          <span className="font-medium text-slate-900">
                            {shipment.mkt_value ? `${shipment.mkt_value.toFixed(1)}°C` : 'N/A'}
                          </span>
                        </p>
                        <p className="text-sm">
                          <span className="text-slate-600">Excursions: </span>
                          <span className={`font-medium ${shipment.excursion_count > 0 ? 'text-red-600' : 'text-green-600'}`}>
                            {shipment.excursion_count || 0}
                          </span>
                        </p>
                      </div>
                    </div>

                    {/* Dataloggers */}
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-slate-600" />
                        <span className="text-sm font-medium text-slate-700">Tracking Devices</span>
                      </div>
                      <div className="space-y-1">
                        {shipmentLoggers.length > 0 ? (
                          <>
                            <p className="text-sm font-medium text-slate-900">
                              {shipmentLoggers.length} device{shipmentLoggers.length > 1 ? 's' : ''} active
                            </p>
                            <div className="flex flex-wrap gap-1">
                              {shipmentLoggers.slice(0, 3).map((logger) => (
                                <Badge key={logger.id} variant="outline" className="text-xs">
                                  {logger.device_name}
                                </Badge>
                              ))}
                              {shipmentLoggers.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{shipmentLoggers.length - 3} more
                                </Badge>
                              )}
                            </div>
                          </>
                        ) : (
                          <p className="text-sm text-slate-500">No devices assigned</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {shipment.current_location && (
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-900">
                        <MapPin className="w-4 h-4 inline mr-1" />
                        Current: {shipment.current_location.address || `${shipment.current_location.lat}, ${shipment.current_location.lng}`}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {shipments.length === 0 && (
          <Card className="border-none shadow-lg">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Package className="w-20 h-20 text-slate-300 mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">No Shipments</h3>
              <p className="text-slate-600">Create your first shipment to start tracking</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
