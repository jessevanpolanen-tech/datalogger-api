
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, Clock, CheckCircle, Sparkles } from "lucide-react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

import AIRecommendations from "../components/alerts/AIRecommendations";

const severityColors = {
  low: "bg-blue-100 text-blue-800 border-blue-200",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
  high: "bg-orange-100 text-orange-800 border-orange-200",
  critical: "bg-red-100 text-red-800 border-red-200"
};

export default function Alerts() {
  const [activeTab, setActiveTab] = useState("active");
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [showAIDialog, setShowAIDialog] = useState(false);
  const [resolutionNotes, setResolutionNotes] = useState("");

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ['alerts', activeTab],
    queryFn: () => {
      if (activeTab === "active") {
        return base44.entities.Alert.filter({ acknowledged: false }, "-created_date");
      }
      return base44.entities.Alert.filter({ acknowledged: true }, "-acknowledged_date");
    },
    initialData: [],
  });

  const acknowledgeMutation = useMutation({
    mutationFn: ({ id, notes }) => base44.entities.Alert.update(id, {
      acknowledged: true,
      acknowledged_by: user?.email || 'system',
      acknowledged_date: new Date().toISOString(),
      resolution_notes: notes
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['alerts'] });
      setShowDialog(false);
      setShowAIDialog(false);
      setSelectedAlert(null);
      setResolutionNotes("");
    },
  });

  const handleAcknowledge = (alert) => {
    setSelectedAlert(alert);
    setShowDialog(true);
  };

  const handleGetAIHelp = (alert) => {
    setSelectedAlert(alert);
    setResolutionNotes("");
    setShowAIDialog(true);
  };

  const confirmAcknowledge = () => {
    if (selectedAlert) {
      acknowledgeMutation.mutate({ 
        id: selectedAlert.id, 
        notes: resolutionNotes 
      });
    }
  };

  const handleApplyAIRecommendations = (recommendations) => {
    setResolutionNotes(prev => {
      if (prev) {
        return prev + "\n\n" + recommendations;
      }
      return recommendations;
    });
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Alert Management</h1>
          <p className="text-slate-600">Monitor and respond to system alerts with AI-powered recommendations</p>
        </div>

        {/* Real-Time Protection Banner */}
        <Card className="border-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50 mb-6">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <div className="flex-1">
                <p className="font-semibold text-green-900">✓ Real-Time Protection Active</p>
                <p className="text-sm text-green-700">
                  Every alert is logged, every response is tracked. 
                  <strong> If it happens, we caught it. If we caught it, you can prove it.</strong>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="active" className="data-[state=active]:bg-red-50 data-[state=active]:text-red-700">
              Active Alerts
            </TabsTrigger>
            <TabsTrigger value="resolved" className="data-[state=active]:bg-green-50 data-[state=active]:text-green-700">
              Resolved
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="grid md:grid-cols-2 gap-6">
          {alerts.length === 0 ? (
            /* Enhanced Empty State */
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 md:col-span-2">
              <CardContent className="flex flex-col items-center justify-center py-16">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-green-900 mb-2">
                  {activeTab === "active" ? "All Clear!" : "No Resolved Alerts"}
                </h3>
                <p className="text-green-800 font-medium text-lg mb-2">
                  {activeTab === "active" 
                    ? "✓ Zero Active Alerts – Your System is Running Flawlessly" 
                    : "No alerts have been resolved yet"}
                </p>
                <p className="text-green-700 text-center max-w-md">
                  {activeTab === "active" && (
                    <>
                      This is <strong>exactly</strong> what you want to show an auditor.
                      All systems operational, compliance intact.
                    </>
                  )}
                </p>
              </CardContent>
            </Card>
          ) : (
            alerts.map((alert) => (
              <Card key={alert.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className={`${severityColors[alert.severity]} border`}>
                      {alert.severity} severity
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <Clock className="w-3 h-3" />
                      {format(new Date(alert.created_date), "MMM d, HH:mm")}
                    </div>
                  </div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className={`w-5 h-5 ${
                      alert.severity === 'critical' ? 'text-red-600' :
                      alert.severity === 'high' ? 'text-orange-600' :
                      alert.severity === 'medium' ? 'text-yellow-600' :
                      'text-blue-600'
                    }`} />
                    {alert.alert_type.replace(/_/g, ' ').toUpperCase()}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-700 mb-4">{alert.message}</p>

                  {alert.value && alert.threshold && (
                    <div className="p-3 bg-slate-50 rounded-lg mb-4">
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <span className="text-slate-600">Measured Value:</span>
                          <p className="font-semibold text-slate-900">{alert.value}</p>
                        </div>
                        <div>
                          <span className="text-slate-600">Threshold:</span>
                          <p className="font-semibold text-slate-900">{alert.threshold}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {alert.acknowledged ? (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-green-700">
                        <CheckCircle className="w-4 h-4" />
                        <span className="font-medium">Resolved by {alert.acknowledged_by}</span>
                      </div>
                      {alert.resolution_notes && (
                        <p className="text-sm text-slate-600 pl-6">{alert.resolution_notes}</p>
                      )}
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleGetAIHelp(alert)}
                        className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        AI Help
                      </Button>
                      <Button
                        onClick={() => handleAcknowledge(alert)}
                        variant="outline"
                        className="flex-1"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Resolve
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Quick Acknowledge Dialog */}
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Acknowledge Alert</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-slate-600">
                Please provide resolution notes for this alert:
              </p>
              <div>
                <Label htmlFor="notes">Resolution Notes</Label>
                <Textarea
                  id="notes"
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  rows={4}
                  placeholder="Describe the corrective action taken..."
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={confirmAcknowledge}
                className="bg-cyan-600 hover:bg-cyan-700"
              >
                Confirm Resolution
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* AI Recommendations Dialog */}
        <Dialog open={showAIDialog} onOpenChange={setShowAIDialog}>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                AI-Powered Alert Resolution Assistant
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Alert Context */}
              {selectedAlert && (
                <Card className="bg-slate-50 border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className={`${severityColors[selectedAlert.severity]} border`}>
                          {selectedAlert.severity}
                        </Badge>
                        <span className="font-medium text-slate-900">
                          {selectedAlert.alert_type.replace(/_/g, ' ')}
                        </span>
                      </div>
                      <span className="text-xs text-slate-500">
                        {format(new Date(selectedAlert.created_date), "MMM d, HH:mm")}
                      </span>
                    </div>
                    <p className="text-sm text-slate-700">{selectedAlert.message}</p>
                  </CardContent>
                </Card>
              )}

              {/* AI Recommendations Component */}
              {selectedAlert && (
                <AIRecommendations 
                  alert={selectedAlert}
                  onSelectAction={handleApplyAIRecommendations}
                />
              )}

              {/* Resolution Notes */}
              <div>
                <Label htmlFor="ai-notes">Resolution Notes</Label>
                <Textarea
                  id="ai-notes"
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  rows={6}
                  placeholder="Selected AI recommendations will appear here, or write your own..."
                  className="mt-2"
                />
                <p className="text-xs text-slate-500 mt-2">
                  Select recommendations above to add them to your resolution notes
                </p>
              </div>
            </div>
            <DialogFooter className="flex gap-2">
              <Button variant="outline" onClick={() => {
                setShowAIDialog(false);
                setResolutionNotes("");
              }}>
                Cancel
              </Button>
              <Button 
                onClick={confirmAcknowledge}
                disabled={!resolutionNotes.trim()}
                className="bg-cyan-600 hover:bg-cyan-700"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Complete Resolution
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
