import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Package, MapPin, Thermometer, AlertTriangle, Clock, TrendingUp, Droplets } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const statusColors = {
  preparing: "bg-blue-100 text-blue-800",
  in_transit: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  returned: "bg-gray-100 text-gray-800",
  exception: "bg-red-100 text-red-800"
};

export default function ShipmentDetail() {
  const navigate = useNavigate();
  const [selectedLogger, setSelectedLogger] = useState(null);

  const urlParams = new URLSearchParams(window.location.search);
  const shipmentId = urlParams.get('shipmentId');

  const { data: shipment } = useQuery({
    queryKey: ['shipment', shipmentId],
    queryFn: () => base44.entities.Shipment.filter({ id: shipmentId }).then(data => data[0]),
    enabled: !!shipmentId,
  });

  const { data: sites = [] } = useQuery({
    queryKey: ['sites'],
    queryFn: () => base44.entities.Site.list(),
    initialData: [],
  });

  const { data: allDataloggers = [] } = useQuery({
    queryKey: ['dataloggers'],
    queryFn: () => base44.entities.Datalogger.list(),
    initialData: [],
  });

  // Get dataloggers for this shipment - now using device_id
  const shipmentDataloggers = allDataloggers.filter(d => 
    shipment?.datalogger_device_ids?.includes(d.device_id)
  );

  const { data: readings = [] } = useQuery({
    queryKey: ['readings', selectedLogger],
    queryFn: () => selectedLogger
      ? base44.entities.Reading.filter({ datalogger_id: selectedLogger }, "-timestamp", 50)
      : Promise.resolve([]),
    enabled: !!selectedLogger,
    initialData: [],
  });

  const getSiteName = (siteId) => {
    const site = sites.find(s => s.id === siteId);
    return site?.name || 'Unknown';
  };

  const chartData = readings.map(r => ({
    time: format(new Date(r.timestamp), "HH:mm"),
    temperature: r.temperature,
    humidity: r.humidity,
  })).reverse();

  const selectedLoggerData = shipmentDataloggers.find(d => d.id === selectedLogger);

  if (!shipment) {
    return (
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <p className="text-slate-600">Loading shipment details...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl('Shipments'))}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Shipments
          </Button>
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 mb-2">{shipment.shipment_number}</h1>
              <p className="text-slate-600">{shipment.product_description}</p>
            </div>
            <Badge className={statusColors[shipment.status]}>
              {shipment.status.replace(/_/g, ' ')}
            </Badge>
          </div>
        </div>

        {/* Shipment Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Route</p>
                  <p className="font-semibold text-slate-900">
                    {getSiteName(shipment.origin_site_id)}
                  </p>
                </div>
              </div>
              <div className="text-center text-slate-400 my-2">↓</div>
              <p className="font-semibold text-slate-900 text-center">
                {getSiteName(shipment.destination_site_id)}
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Timeline</p>
                  <p className="font-semibold text-slate-900">In Transit</p>
                </div>
              </div>
              {shipment.departure_time && (
                <p className="text-xs text-slate-600">
                  Departed: {format(new Date(shipment.departure_time), "MMM d, HH:mm")}
                </p>
              )}
              {shipment.expected_arrival && (
                <p className="text-xs text-slate-600">
                  Expected: {format(new Date(shipment.expected_arrival), "MMM d, HH:mm")}
                </p>
              )}
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  shipment.temperature_compliant ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  <Thermometer className={`w-6 h-6 ${
                    shipment.temperature_compliant ? 'text-green-600' : 'text-red-600'
                  }`} />
                </div>
                <div>
                  <p className="text-sm text-slate-600">Temperature Status</p>
                  <p className={`font-semibold ${
                    shipment.temperature_compliant ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {shipment.temperature_compliant ? 'Compliant' : 'Excursion Detected'}
                  </p>
                </div>
              </div>
              <p className="text-xs text-slate-600">
                MKT: {shipment.mkt_value ? `${shipment.mkt_value.toFixed(1)}°C` : 'Calculating...'}
              </p>
              <p className="text-xs text-slate-600">
                Excursions: {shipment.excursion_count || 0}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Dataloggers Section */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Logger List */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-cyan-600" />
                Tracking Devices ({shipmentDataloggers.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {shipmentDataloggers.length === 0 ? (
                  <p className="text-sm text-slate-500">No dataloggers assigned to this shipment</p>
                ) : (
                  shipmentDataloggers.map((logger) => (
                    <button
                      key={logger.id}
                      onClick={() => setSelectedLogger(logger.id)}
                      className={`w-full text-left p-4 rounded-xl border transition-all duration-200 ${
                        selectedLogger === logger.id
                          ? 'bg-cyan-50 border-cyan-300 shadow-md'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-semibold text-slate-900">{logger.device_name}</h4>
                          <p className="text-xs text-slate-600">{logger.device_id}</p>
                        </div>
                        <Badge className={
                          logger.status === 'active' ? 'bg-green-100 text-green-800' :
                          logger.status === 'alarm' ? 'bg-red-100 text-red-800' :
                          'bg-slate-100 text-slate-800'
                        }>
                          {logger.status}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between text-xs text-slate-600 mt-2">
                        <span className="flex items-center gap-1">
                          {logger.device_type.includes('temperature') && <Thermometer className="w-3 h-3" />}
                          {logger.device_type.includes('humidity') && <Droplets className="w-3 h-3" />}
                          {logger.device_type.replace(/_/g, ' ')}
                        </span>
                        <span>Battery: {logger.battery_level}%</span>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Logger Data Visualization */}
          <div className="lg:col-span-2 space-y-6">
            {selectedLoggerData ? (
              <>
                <Card className="border-none shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-cyan-600" />
                      {selectedLoggerData.device_name} - Live Data
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="p-4 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Thermometer className="w-4 h-4 text-red-600" />
                          <span className="text-sm font-medium text-slate-600">Current Temp</span>
                        </div>
                        <p className="text-2xl font-bold text-slate-900">
                          {readings[0]?.temperature?.toFixed(1) || '--'}°C
                        </p>
                      </div>
                      
                      <div className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Droplets className="w-4 h-4 text-blue-600" />
                          <span className="text-sm font-medium text-slate-600">Humidity</span>
                        </div>
                        <p className="text-2xl font-bold text-slate-900">
                          {readings[0]?.humidity?.toFixed(1) || '--'}%
                        </p>
                      </div>

                      <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingUp className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-medium text-slate-600">Avg Temp</span>
                        </div>
                        <p className="text-2xl font-bold text-slate-900">
                          {readings.length > 0
                            ? (readings.reduce((sum, r) => sum + (r.temperature || 0), 0) / readings.length).toFixed(1)
                            : '--'}°C
                        </p>
                      </div>

                      <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock className="w-4 h-4 text-purple-600" />
                          <span className="text-sm font-medium text-slate-600">Last Update</span>
                        </div>
                        <p className="text-sm font-bold text-slate-900">
                          {readings[0] ? format(new Date(readings[0].timestamp), "HH:mm:ss") : '--'}
                        </p>
                      </div>
                    </div>

                    {chartData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="time" stroke="#64748b" style={{ fontSize: '12px' }} />
                          <YAxis yAxisId="left" stroke="#64748b" style={{ fontSize: '12px' }} />
                          <YAxis yAxisId="right" orientation="right" stroke="#64748b" style={{ fontSize: '12px' }} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: 'white', 
                              border: '1px solid #e2e8f0',
                              borderRadius: '8px'
                            }}
                          />
                          <Legend />
                          <Line 
                            yAxisId="left"
                            type="monotone" 
                            dataKey="temperature" 
                            stroke="#ef4444" 
                            strokeWidth={2}
                            dot={false}
                            name="Temperature (°C)"
                          />
                          <Line 
                            yAxisId="right"
                            type="monotone" 
                            dataKey="humidity" 
                            stroke="#3b82f6" 
                            strokeWidth={2}
                            dot={false}
                            name="Humidity (%)"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="text-center py-12">
                        <Thermometer className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500">No data available for this logger</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Logger Details */}
                <Card className="border-none shadow-lg">
                  <CardHeader>
                    <CardTitle>Device Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-slate-600">Device ID</p>
                        <p className="font-medium text-slate-900">{selectedLoggerData.device_id}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Connection</p>
                        <p className="font-medium text-slate-900">{selectedLoggerData.connection_type?.toUpperCase()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Firmware</p>
                        <p className="font-medium text-slate-900">{selectedLoggerData.firmware_version}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-600">Battery Level</p>
                        <p className={`font-medium ${selectedLoggerData.battery_level < 20 ? 'text-red-600' : 'text-slate-900'}`}>
                          {selectedLoggerData.battery_level}%
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="border-none shadow-lg h-full">
                <CardContent className="flex items-center justify-center h-[500px]">
                  <div className="text-center">
                    <Package className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 text-lg">Select a datalogger to view its data</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Additional Shipment Info */}
        {(shipment.batch_number || shipment.po_number || shipment.carrier || shipment.notes) && (
          <Card className="border-none shadow-lg mt-6">
            <CardHeader>
              <CardTitle>Additional Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {shipment.batch_number && (
                  <div>
                    <p className="text-sm text-slate-600">Batch Number</p>
                    <p className="font-medium text-slate-900">{shipment.batch_number}</p>
                  </div>
                )}
                {shipment.po_number && (
                  <div>
                    <p className="text-sm text-slate-600">PO Number</p>
                    <p className="font-medium text-slate-900">{shipment.po_number}</p>
                  </div>
                )}
                {shipment.carrier && (
                  <div>
                    <p className="text-sm text-slate-600">Carrier</p>
                    <p className="font-medium text-slate-900">{shipment.carrier}</p>
                  </div>
                )}
                {shipment.notes && (
                  <div className="md:col-span-2">
                    <p className="text-sm text-slate-600">Notes</p>
                    <p className="font-medium text-slate-900">{shipment.notes}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}