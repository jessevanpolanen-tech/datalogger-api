import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Thermometer, Droplets, Activity, MapPin, Clock, Battery } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { format } from "date-fns";

const statusColors = {
  active: "bg-green-100 text-green-800 border-green-200",
  alarm: "bg-red-100 text-red-800 border-red-200",
  maintenance: "bg-yellow-100 text-yellow-800 border-yellow-200",
  inactive: "bg-slate-100 text-slate-800 border-slate-200"
};

export default function Monitoring() {
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [timeRange, setTimeRange] = useState("24h");

  // Get device ID from URL parameters
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const deviceId = urlParams.get('deviceId');
    if (deviceId) {
      setSelectedDevice(deviceId);
    }
  }, []);

  const { data: dataloggers = [], isLoading } = useQuery({
    queryKey: ['dataloggers'],
    queryFn: () => base44.entities.Datalogger.list(),
    initialData: [],
  });

  const { data: readings = [] } = useQuery({
    queryKey: ['readings', selectedDevice],
    queryFn: () => selectedDevice 
      ? base44.entities.Reading.filter({ datalogger_id: selectedDevice }, "-timestamp", 100)
      : Promise.resolve([]),
    enabled: !!selectedDevice,
    initialData: [],
  });

  const selectedDeviceData = dataloggers.find(d => d.id === selectedDevice);

  const chartData = readings.map(r => ({
    time: format(new Date(r.timestamp), "HH:mm"),
    temperature: r.temperature,
    humidity: r.humidity,
  })).reverse();

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Live Monitoring</h1>
          <p className="text-slate-600">Real-time data from IoT dataloggers</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-1 border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-600" />
                Devices
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {dataloggers.map((device) => (
                  <button
                    key={device.id}
                    onClick={() => setSelectedDevice(device.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-all duration-200 ${
                      selectedDevice === device.id
                        ? 'bg-cyan-50 border-cyan-300 shadow-md'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-slate-900">{device.device_name}</h4>
                      <Badge className={`${statusColors[device.status]} border text-xs`}>
                        {device.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-slate-500 mb-2">
                      <MapPin className="w-3 h-3" />
                      {device.location}
                    </div>
                    <div className="flex items-center justify-between text-xs text-slate-600">
                      <span className="flex items-center gap-1">
                        {device.device_type.includes('temperature') && <Thermometer className="w-3 h-3" />}
                        {device.device_type.includes('humidity') && <Droplets className="w-3 h-3" />}
                        {device.device_type.replace(/_/g, ' ')}
                      </span>
                      <span className="flex items-center gap-1">
                        <Battery className={`w-3 h-3 ${device.battery_level > 20 ? 'text-green-500' : 'text-red-500'}`} />
                        {device.battery_level}%
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="lg:col-span-2 space-y-6">
            {selectedDeviceData ? (
              <>
                <Card className="border-none shadow-lg">
                  <CardHeader>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <CardTitle className="flex items-center gap-2">
                        <Thermometer className="w-5 h-5 text-cyan-600" />
                        {selectedDeviceData.device_name}
                      </CardTitle>
                      <Tabs value={timeRange} onValueChange={setTimeRange}>
                        <TabsList>
                          <TabsTrigger value="24h">24h</TabsTrigger>
                          <TabsTrigger value="7d">7d</TabsTrigger>
                          <TabsTrigger value="30d">30d</TabsTrigger>
                        </TabsList>
                      </Tabs>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="p-4 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Thermometer className="w-4 h-4 text-red-600" />
                          <span className="text-sm font-medium text-slate-600">Temperature</span>
                        </div>
                        <p className="text-2xl font-bold text-slate-900">
                          {readings[0]?.temperature?.toFixed(1) || '--'}°C
                        </p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Droplets className="w-4 h-4 text-blue-600" />
                          <span className="text-sm font-medium text-slate-600">Humidity</span>
                        </div>
                        <p className="text-2xl font-bold text-slate-900">
                          {readings[0]?.humidity?.toFixed(1) || '--'}%
                        </p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Battery className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-medium text-slate-600">Battery</span>
                        </div>
                        <p className="text-2xl font-bold text-slate-900">
                          {selectedDeviceData.battery_level}%
                        </p>
                      </div>
                      <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock className="w-4 h-4 text-purple-600" />
                          <span className="text-sm font-medium text-slate-600">Last Update</span>
                        </div>
                        <p className="text-sm font-bold text-slate-900">
                          {readings[0] ? format(new Date(readings[0].timestamp), "HH:mm:ss") : '--'}
                        </p>
                      </div>
                    </div>

                    {chartData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                          <XAxis dataKey="time" stroke="#64748b" style={{ fontSize: '12px' }} />
                          <YAxis yAxisId="left" stroke="#64748b" style={{ fontSize: '12px' }} />
                          <YAxis yAxisId="right" orientation="right" stroke="#64748b" style={{ fontSize: '12px' }} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: 'white', 
                              border: '1px solid #e2e8f0',
                              borderRadius: '8px'
                            }}
                          />
                          <Legend />
                          <Line 
                            yAxisId="left"
                            type="monotone" 
                            dataKey="temperature" 
                            stroke="#ef4444" 
                            strokeWidth={2}
                            dot={false}
                            name="Temperature (°C)"
                          />
                          <Line 
                            yAxisId="right"
                            type="monotone" 
                            dataKey="humidity" 
                            stroke="#3b82f6" 
                            strokeWidth={2}
                            dot={false}
                            name="Humidity (%)"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="text-center py-12">
                        <Activity className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-500">No data available for this device</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card className="border-none shadow-lg h-full">
                <CardContent className="flex items-center justify-center h-[600px]">
                  <div className="text-center">
                    <Activity className="w-20 h-20 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 text-lg">Select a device to view monitoring data</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}