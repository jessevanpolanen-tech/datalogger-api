
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, FileText, Filter, Download } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import ReportCard from "../components/reports/ReportCard";
import ReportPreview from "../components/reports/ReportPreview";
import ReportGenerationDialog from "../components/reports/ReportGenerationDialog";

export default function Reports() {
  const [showDialog, setShowDialog] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const queryClient = useQueryClient();

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ['reports'],
    queryFn: () => base44.entities.Report.list("-created_date"),
    initialData: [],
  });

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: dataloggers = [] } = useQuery({
    queryKey: ['dataloggers'],
    queryFn: () => base44.entities.Datalogger.list(),
    initialData: [],
  });

  const { data: controlPoints = [] } = useQuery({
    queryKey: ['controlPoints'],
    queryFn: () => base44.entities.ControlPoint.list(),
    initialData: [],
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ['allAlerts'],
    queryFn: () => base44.entities.Alert.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      setGenerating(true);
      
      const reportData = {
        ...data,
        generated_by: user?.email || 'system',
      };

      // Generate comprehensive summary based on actual data
      const totalDevices = dataloggers.length;
      const activeDevices = dataloggers.filter(d => d.status === 'active').length;
      const totalCCPs = controlPoints.length;
      const compliantCCPs = controlPoints.filter(cp => cp.status === 'compliant').length;
      const complianceRate = totalCCPs > 0 ? ((compliantCCPs / totalCCPs) * 100).toFixed(1) : 100;
      const totalAlerts = alerts.length;
      const criticalAlerts = alerts.filter(a => a.severity === 'critical').length;

      let summaryPrompt = `Generate a professional executive summary for a ${data.report_type.replace(/_/g, ' ')} covering ${data.period_start} to ${data.period_end}. `;
      
      summaryPrompt += `System Status: ${activeDevices}/${totalDevices} devices active, ${totalCCPs} control points with ${complianceRate}% compliance rate, ${totalAlerts} total alerts including ${criticalAlerts} critical. `;
      
      if (data.notes) {
        summaryPrompt += `Additional context: ${data.notes}. `;
      }

      summaryPrompt += `Write 2-3 paragraphs in a professional, regulatory-compliant tone suitable for pharmaceutical industry documentation.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: summaryPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            executive_summary: { type: "string" },
            key_metrics: {
              type: "object",
              properties: {
                compliance_rate: { type: "number" },
                total_readings: { type: "number" },
                deviations_count: { type: "number" }
              }
            }
          }
        }
      });

      reportData.summary = result.executive_summary || `Comprehensive ${data.report_type.replace(/_/g, ' ')} for the period ${data.period_start} to ${data.period_end}. System maintained ${complianceRate}% compliance with ${activeDevices} active monitoring devices across ${totalCCPs} critical control points.`;

      return base44.entities.Report.create(reportData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
      setShowDialog(false);
      setGenerating(false);
    },
    onError: (error) => {
      console.error("Error generating report:", error);
      setGenerating(false);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Report.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
    },
  });

  const handleGenerate = (formData) => {
    createMutation.mutate(formData);
  };

  const handleDownload = (report) => {
    // Create a simple text representation for download
    const content = `
${report.title}
${'='.repeat(report.title.length)}

Report Type: ${report.report_type.replace(/_/g, ' ').toUpperCase()}
Period: ${report.period_start} to ${report.period_end}
Generated By: ${report.generated_by}
Status: ${report.status}

EXECUTIVE SUMMARY
${report.summary}

---
Report ID: ${report.id}
Generated: ${new Date(report.created_date).toLocaleString()}
    `.trim();

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${report.title.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const filteredReports = reports.filter(report => {
    if (filterType !== "all" && report.report_type !== filterType) return false;
    if (filterStatus !== "all" && report.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Compliance Reports</h1>
            <p className="text-slate-600">Auto-generated HACCP documentation and analytics</p>
          </div>
          <Button 
            onClick={() => setShowDialog(true)}
            className="bg-cyan-600 hover:bg-cyan-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Generate Report
          </Button>
        </div>

        {/* One-Click Compliance Reports Banner */}
        <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-cyan-50 mb-8">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-blue-900 mb-2">
                  ✓ One-Click Compliance Reports
                </h3>
                <p className="text-blue-800 mb-3">
                  Generate audit-ready documentation that satisfies:
                </p>
                <ul className="text-sm text-blue-700 space-y-1 mb-4">
                  <li>• <strong>FDA inspections</strong> (21 CFR Part 11)</li>
                  <li>• <strong>EU GDP audits</strong> (temperature records, chain of custody)</li>
                  <li>• <strong>HACCP verification</strong> (critical control point logs)</li>
                  <li>• <strong>WHO PQS standards</strong> (pharmaceutical quality system)</li>
                </ul>
                <p className="text-sm text-blue-900 font-semibold">
                  🔒 All reports are cryptographically signed and tamper-proof.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Export & Ownership Section */}
        <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-900">
              <Download className="w-5 h-5" />
              Export All Data – Your Data, Your Control
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-700 mb-4">
              <strong>No vendor lock-in. Ever.</strong> Export your complete dataset in any format you need.
            </p>
            <div className="grid md:grid-cols-4 gap-3">
              <Button variant="outline" className="justify-start">
                <FileText className="w-4 h-4 mr-2" />
                CSV (Raw sensor data)
              </Button>
              <Button variant="outline" className="justify-start">
                <FileText className="w-4 h-4 mr-2" />
                Excel (Formatted logs)
              </Button>
              <Button variant="outline" className="justify-start">
                <FileText className="w-4 h-4 mr-2" />
                JSON (API-ready)
              </Button>
              <Button variant="outline" className="justify-start">
                <FileText className="w-4 h-4 mr-2" />
                PDF (Archives)
              </Button>
            </div>
            <p className="text-sm text-purple-700 mt-4 font-medium">
              ✓ Complete data portability • ✓ No hidden fees • ✓ Instant downloads
            </p>
          </CardContent>
        </Card>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-500" />
            <span className="text-sm text-slate-600">Filters:</span>
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Report Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="daily_summary">Daily Summary</SelectItem>
              <SelectItem value="deviation_report">Deviation Report</SelectItem>
              <SelectItem value="audit_trail">Audit Trail</SelectItem>
              <SelectItem value="compliance_certificate">Compliance Certificate</SelectItem>
              <SelectItem value="haccp_plan">HACCP Plan</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="finalized">Finalized</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Reports Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-80 bg-slate-100 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredReports.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 mb-2">No reports found</h3>
            <p className="text-slate-600 mb-4">
              {filterType !== "all" || filterStatus !== "all" 
                ? "Try adjusting your filters" 
                : "Generate your first compliance report"}
            </p>
            {(filterType !== "all" || filterStatus !== "all") && (
              <Button
                variant="outline"
                onClick={() => {
                  setFilterType("all");
                  setFilterStatus("all");
                }}
              >
                Clear Filters
              </Button>
            )}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredReports.map((report) => (
              <ReportCard
                key={report.id}
                report={report}
                onView={setSelectedReport}
                onDelete={(id) => deleteMutation.mutate(id)}
              />
            ))}
          </div>
        )}

        {/* Report Generation Dialog */}
        <ReportGenerationDialog
          open={showDialog}
          onClose={() => setShowDialog(false)}
          onGenerate={handleGenerate}
          generating={generating}
        />

        {/* Report Preview */}
        {selectedReport && (
          <ReportPreview
            report={selectedReport}
            onClose={() => setSelectedReport(null)}
            onDownload={() => handleDownload(selectedReport)}
          />
        )}
      </div>
    </div>
  );
}
