import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Thermometer, Calendar, AlertCircle, Plus, Upload } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Devices() {
  const [activeTab, setActiveTab] = useState("all");
  const navigate = useNavigate();

  const { data: dataloggers = [] } = useQuery({
    queryKey: ['dataloggers'],
    queryFn: () => base44.entities.Datalogger.list("-created_date"),
    initialData: [],
  });

  const { data: calibrations = [] } = useQuery({
    queryKey: ['calibrations'],
    queryFn: () => base44.entities.Calibration.list("-calibration_date", 50),
    initialData: [],
  });

  const filteredDevices = dataloggers.filter(device => {
    if (activeTab === "all") return true;
    if (activeTab === "calibration_due") {
      if (!device.next_calibration_due) return false;
      const daysUntil = differenceInDays(new Date(device.next_calibration_due), new Date());
      return daysUntil <= 30;
    }
    if (activeTab === "offline") return device.status === 'offline' || device.status === 'inactive';
    if (activeTab === "low_battery") return device.battery_level && device.battery_level < 20;
    return true;
  });

  const getCalibrationStatus = (device) => {
    if (!device.next_calibration_due) return { status: 'unknown', color: 'bg-gray-100 text-gray-800', days: null };
    
    const daysUntil = differenceInDays(new Date(device.next_calibration_due), new Date());
    
    if (daysUntil < 0) return { status: 'overdue', color: 'bg-red-100 text-red-800 border-red-200', days: Math.abs(daysUntil) };
    if (daysUntil <= 7) return { status: 'urgent', color: 'bg-orange-100 text-orange-800 border-orange-200', days: daysUntil };
    if (daysUntil <= 30) return { status: 'due soon', color: 'bg-yellow-100 text-yellow-800 border-yellow-200', days: daysUntil };
    return { status: 'current', color: 'bg-green-100 text-green-800 border-green-200', days: daysUntil };
  };

  const handleDeviceClick = (deviceId) => {
    navigate(createPageUrl('Monitoring') + '?deviceId=' + deviceId);
  };

  return (
    <div className="p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Device Management</h1>
            <p className="text-slate-600">Calibration tracking and device health monitoring</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Upload className="w-4 h-4 mr-2" />
              Bulk Import
            </Button>
            <Button className="bg-cyan-600 hover:bg-cyan-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Device
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="all">
              All Devices ({dataloggers.length})
            </TabsTrigger>
            <TabsTrigger value="calibration_due">
              Calibration Due ({dataloggers.filter(d => {
                if (!d.next_calibration_due) return false;
                return differenceInDays(new Date(d.next_calibration_due), new Date()) <= 30;
              }).length})
            </TabsTrigger>
            <TabsTrigger value="offline">
              Offline ({dataloggers.filter(d => d.status === 'offline' || d.status === 'inactive').length})
            </TabsTrigger>
            <TabsTrigger value="low_battery">
              Low Battery ({dataloggers.filter(d => d.battery_level && d.battery_level < 20).length})
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Device Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDevices.map((device) => {
            const calibStatus = getCalibrationStatus(device);
            const deviceCalibrations = calibrations.filter(c => c.datalogger_id === device.id);
            
            return (
              <Card 
                key={device.id} 
                className="border-none shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => handleDeviceClick(device.id)}
              >
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <Thermometer className="w-5 h-5 text-cyan-600" />
                      <CardTitle className="text-lg">{device.device_name}</CardTitle>
                    </div>
                    <Badge className={`${
                      device.status === 'active' ? 'bg-green-100 text-green-800' :
                      device.status === 'offline' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {device.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600">{device.location}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {/* Device Info */}
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-slate-600">Type:</span>
                        <p className="font-medium">{device.device_type.replace(/_/g, ' ')}</p>
                      </div>
                      <div>
                        <span className="text-slate-600">Connection:</span>
                        <p className="font-medium">{device.connection_type?.toUpperCase() || 'WiFi'}</p>
                      </div>
                      <div>
                        <span className="text-slate-600">Battery:</span>
                        <p className={`font-medium ${device.battery_level < 20 ? 'text-red-600' : ''}`}>
                          {device.battery_level}%
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-600">Firmware:</span>
                        <p className="font-medium">{device.firmware_version || 'v1.0'}</p>
                      </div>
                    </div>

                    {/* Calibration Status */}
                    <div className="p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="w-4 h-4 text-slate-600" />
                        <span className="text-sm font-medium text-slate-700">Calibration Status</span>
                      </div>
                      
                      {device.next_calibration_due ? (
                        <>
                          <Badge variant="outline" className={`${calibStatus.color} border mb-2`}>
                            {calibStatus.status.toUpperCase()}
                            {calibStatus.days !== null && ` - ${calibStatus.days} days`}
                          </Badge>
                          <p className="text-xs text-slate-600">
                            Due: {format(new Date(device.next_calibration_due), "MMM d, yyyy")}
                          </p>
                          {device.last_calibration_date && (
                            <p className="text-xs text-slate-600">
                              Last: {format(new Date(device.last_calibration_date), "MMM d, yyyy")}
                            </p>
                          )}
                        </>
                      ) : (
                        <Badge variant="outline" className="bg-gray-100 text-gray-800">
                          No schedule set
                        </Badge>
                      )}

                      {deviceCalibrations.length > 0 && (
                        <p className="text-xs text-slate-500 mt-2">
                          {deviceCalibrations.length} calibration{deviceCalibrations.length > 1 ? 's' : ''} on record
                        </p>
                      )}
                    </div>

                    {/* Drift Offset */}
                    {device.drift_offset && (
                      <div className="flex items-center gap-2 text-sm text-orange-700 bg-orange-50 p-2 rounded">
                        <AlertCircle className="w-4 h-4" />
                        <span>Drift offset: {device.drift_offset}°C</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}